#!/usr/bin/env python3
# tg-notify-template.py — 手機回報腳本（核心包 v0 選配模組）
# 安裝：完成 README 第 8 步後，本檔由安裝精靈複製為 tg-notify.py
# 用法：python3 tg-notify.py "訊息內容"
# 設計原則：只用 Python 內建函式庫，不需安裝任何套件；失敗不擋主流程
import json
import sys
import urllib.request
import urllib.parse
from pathlib import Path

CONFIG = Path(__file__).parent / "config" / "tg.json"


def main():
    if not CONFIG.exists():
        print("尚未設定手機回報：請先完成 README 第 8 步")
        sys.exit(1)
    cfg = json.loads(CONFIG.read_text())
    text = " ".join(sys.argv[1:]).strip()
    if not text:
        text = sys.stdin.read().strip()
    if not text:
        print("沒有訊息內容")
        sys.exit(1)
    data = urllib.parse.urlencode({
        "chat_id": cfg["chat_id"],
        "text": text,
    }).encode()
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{cfg['bot_token']}/sendMessage",
        data=data,
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            ok = json.loads(r.read()).get("ok")
        print("已送出到你的手機" if ok else "送出失敗（Telegram 回應異常，檢查 config/tg.json 的 token 與 chat_id）")
    except Exception as e:
        # 回報功能故障不影響產文/送審主流程（自動化不停線原則）
        print(f"送出失敗：{e}（不影響其他功能，可稍後重試）")


if __name__ == "__main__":
    main()
